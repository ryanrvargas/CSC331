package com.example.passwordgenerator;

public interface passwordInterface{
    void generateP();
    void setLength(int length);
}
